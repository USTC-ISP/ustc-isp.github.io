#include "router.h"
#include <stdlib.h>
#include <string.h>

/*
 * TODO:
 * 1. 实现 router_create
 * 2. 实现 router_route
 * 3. 实现 router_destroy
 *
 * 优化建议：
 * - 不要对每个 token 的所有 expert 做完整排序
 * - 由于 k 很小，可以只维护当前前 k 名
 * - 分数相同的时候，expert_id 小的更优
 */

Router* router_create(int num_experts, int top_k) {
    Router* router = (Router*)malloc(sizeof(Router));
    if (router == NULL) {
        return NULL;
    }
    router->num_experts = num_experts;
    router->top_k = top_k;
    return router;
}

void router_route(Router* router, const int* scores, int num_tokens, RouteResult* out) {
    /*
     * 学生需要自行完成。
     * 你可以：
     * 1. 先把 out->expert_load 清零
     * 2. 逐个 token 扫描其分数
     * 3. 维护当前 token 的 top-k
     * 4. 写回 out->topk_indices / out->topk_scores
     * 5. 更新负载统计
     */

    (void)router;
    (void)scores;
    (void)num_tokens;
    (void)out;
}

void router_destroy(Router* router) {
    free(router);
}
