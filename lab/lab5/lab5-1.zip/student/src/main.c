#include "router.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <math.h>

#define DEFAULT_ROUNDS 10
#define DEFAULT_SEED 42

static double now_seconds(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + (double)tv.tv_usec * 1e-6;
}

static void fill_random_scores(int* scores, int num_tokens, int num_experts, unsigned int seed) {
    srand(seed);
    size_t total = (size_t)num_tokens * (size_t)num_experts;
    for (size_t i = 0; i < total; ++i) {
        scores[i] = rand() % 1000;
    }
}

static void free_result(RouteResult* result) {
    if (result) {
        free(result->topk_indices);
        free(result->topk_scores);
        free(result->expert_load);
    }
}

// Check if two results are identical
static int check_correctness(int num_tokens, int num_experts, int top_k, RouteResult* ref, RouteResult* out) {
    for (int i = 0; i < num_tokens * top_k; ++i) {
        if (ref->topk_indices[i] != out->topk_indices[i] || ref->topk_scores[i] != out->topk_scores[i]) {
            return 0;
        }
    }
    for (int i = 0; i < num_experts; ++i) {
        if (ref->expert_load[i] != out->expert_load[i]) {
            return 0;
        }
    }
    return 1;
}

// "最笨"的基线实现：对每个 token 的所有专家进行完整排序
static int compare_experts(const void* a, const void* b) {
    const ExpertScore* ea = (const ExpertScore*)a;
    const ExpertScore* eb = (const ExpertScore*)b;
    if (ea->score != eb->score) {
        return eb->score - ea->score; // 降序
    }
    return ea->expert_id - eb->expert_id; // id 升序
}

void router_route_baseline(int num_experts, int top_k, const int* scores, int num_tokens, RouteResult* out) {
    memset(out->expert_load, 0, (size_t)num_experts * sizeof(int));
    ExpertScore* temp = (ExpertScore*)malloc((size_t)num_experts * sizeof(ExpertScore));
    
    for (int t = 0; t < num_tokens; ++t) {
        const int* row = scores + (size_t)t * (size_t)num_experts;
        for (int j = 0; j < num_experts; ++j) {
            temp[j].expert_id = j;
            temp[j].score = row[j];
        }
        
        qsort(temp, (size_t)num_experts, sizeof(ExpertScore), compare_experts);
        
        for (int r = 0; r < top_k; ++r) {
            int idx = t * top_k + r;
            out->topk_indices[idx] = temp[r].expert_id;
            out->topk_scores[idx] = temp[r].score;
            out->expert_load[temp[r].expert_id]++;
        }
    }
    free(temp);
}

static double run_benchmark(int num_tokens, int num_experts, int top_k, int rounds) {
    int* scores = (int*)malloc((size_t)num_tokens * (size_t)num_experts * sizeof(int));
    fill_random_scores(scores, num_tokens, num_experts, DEFAULT_SEED);

    RouteResult res_baseline, res_student;
    res_baseline.topk_indices = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    res_baseline.topk_scores = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    res_baseline.expert_load = (int*)malloc((size_t)num_experts * sizeof(int));

    res_student.topk_indices = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    res_student.topk_scores = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    res_student.expert_load = (int*)malloc((size_t)num_experts * sizeof(int));

    // Warmup and correctness check
    router_route_baseline(num_experts, top_k, scores, num_tokens, &res_baseline);
    Router* router = router_create(num_experts, top_k);
    router_route(router, scores, num_tokens, &res_student);
    
    int correct = check_correctness(num_tokens, num_experts, top_k, &res_baseline, &res_student);

    // Baseline benchmark
    double start = now_seconds();
    for (int i = 0; i < rounds; ++i) {
        router_route_baseline(num_experts, top_k, scores, num_tokens, &res_baseline);
    }
    double end = now_seconds();
    double baseline_avg_token_time = ((end - start) / rounds) / num_tokens;

    // Student benchmark
    start = now_seconds();
    for (int i = 0; i < rounds; ++i) {
        router_route(router, scores, num_tokens, &res_student);
    }
    end = now_seconds();
    double student_avg_token_time = ((end - start) / rounds) / num_tokens;
    double speedup = baseline_avg_token_time / student_avg_token_time;

    printf("| %7d | %7d | %2d | %12.3f | %12.3f | %8.2fx | %10s |\n",
           num_tokens, num_experts, top_k,
           baseline_avg_token_time * 1e6,
           student_avg_token_time * 1e6,
           speedup,
           correct ? "PASS" : "FAIL");

    router_destroy(router);
    free(scores);
    free_result(&res_baseline);
    free_result(&res_student);
    
    return speedup;
}

int main(int argc, char** argv) {
    if (argc > 1 && strcmp(argv[1], "--bench") == 0) {
        printf("\nStarting Multi-Scale Benchmark...\n");
        printf("|  Tokens  | Experts | K  | Baseline(us) | Student(us)  | Speedup  | Correct?   |\n");
        printf("|----------|---------|----|--------------|--------------|----------|------------|\n");

        int configs[][3] = {
            {512,  128, 2},
            {1000, 512, 4},
            {2048, 1024, 8},
            {4096, 2048, 16}
        };
        int num_configs = sizeof(configs) / sizeof(configs[0]);
        double log_sum = 0;

        for (int i = 0; i < num_configs; ++i) {
            double speedup = run_benchmark(configs[i][0], configs[i][1], configs[i][2], DEFAULT_ROUNDS);
            log_sum += log(speedup);
        }
        
        double gmean = exp(log_sum / num_configs);
        printf("|----------|---------|----|--------------|--------------|----------|------------|\n");
        printf("| GMEAN SPEEDUP                                         | %8.2fx |            |\n", gmean);
        printf("\n");
        return 0;
    }

    int num_tokens = 0;
    int num_experts = 0;
    int top_k = 0;

    if (scanf("%d %d %d", &num_tokens, &num_experts, &top_k) != 3) {
        return 1;
    }

    if (num_tokens <= 0 || num_experts <= 0 || top_k <= 0 || top_k > num_experts) {
        return 1;
    }

    int* scores = (int*)malloc((size_t)num_tokens * (size_t)num_experts * sizeof(int));
    if (scores == NULL) {
        return 1;
    }

    for (int i = 0; i < num_tokens; ++i) {
        for (int j = 0; j < num_experts; ++j) {
            if (scanf("%d", &scores[i * num_experts + j]) != 1) {
                free(scores);
                return 1;
            }
        }
    }

    RouteResult result;
    result.topk_indices = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    result.topk_scores = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    result.expert_load = (int*)malloc((size_t)num_experts * sizeof(int));

    if (result.topk_indices == NULL || result.topk_scores == NULL || result.expert_load == NULL) {
        free(scores);
        free_result(&result);
        return 1;
    }

    Router* router = router_create(num_experts, top_k);
    if (router == NULL) {
        free(scores);
        free_result(&result);
        return 1;
    }

    router_route(router, scores, num_tokens, &result);

    for (int i = 0; i < num_tokens; ++i) {
        printf("token %d:", i);
        for (int r = 0; r < top_k; ++r) {
            int idx = i * top_k + r;
            printf(" %d(%d)", result.topk_indices[idx], result.topk_scores[idx]);
        }
        printf("\n");
    }

    printf("load:");
    for (int j = 0; j < num_experts; ++j) {
        printf(" %d", result.expert_load[j]);
    }
    printf("\n");

    router_destroy(router);
    free(scores);
    free_result(&result);
    return 0;
}
