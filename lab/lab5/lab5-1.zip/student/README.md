# lab5-1: MoE Top-k Router 实验

## 快速开始

### 编译项目

```bash
cd student
cmake -S . -B build
cmake --build build
```

编译成功后，可执行文件位于 `build/moe_router`。

### 运行单元测试

```bash
./build/moe_router 
```

然后手动输入样例数据。

示例输入：

```text
3 4 2
8 1 5 7
2 9 9 1
6 6 3 6
```

预期输出：

```text
token 0: 0(8) 3(7)
token 1: 1(9) 2(9)
token 2: 0(6) 1(6)
load: 2 2 1 1
```

### 运行性能测试

```bash
./build/moe_router --bench
```

性能测试会：
- 自动生成多个规模的测试数据
- 对比你的实现与基线（完整排序）的结果，验证正确性
- 输出处理每个 Token 的平均耗时（微秒）
- 计算加速比和几何平均加速比 (GMEAN)

输出示例：

```
Starting Multi-Scale Benchmark...
|  Tokens  | Experts | K  | Baseline(us) | Student(us)  | Speedup  | Correct?   |
|----------|---------|----|--------------|--------------|----------|------------|
|     512  |     128 |  2 |       15.230 |        1.850 |    8.23x |       PASS |
|    1000  |     512 |  4 |       85.450 |        5.120 |   16.69x |       PASS |
|    2048  |    1024 |  8 |      192.120 |        9.450 |   20.33x |       PASS |
|    4096  |    2048 | 16 |      450.300 |       18.200 |   24.74x |       PASS |
|----------|---------|----|--------------|--------------|----------|------------|
| GMEAN SPEEDUP                                         |   17.18x |            |
```

**表格说明**：
- **Baseline(us)**：全排序基线算法，处理每个 token 的平均耗时（微秒）
- **Student(us)**：你的实现的平均耗时
- **Speedup**：加速倍数（基线耗时 ÷ 你的耗时）
- **Correct?**：是否与基线输出一致（正确性验证）
- **GMEAN SPEEDUP**：所有规模的几何平均加速比

如果某行显示 `FAIL`，说明你的实现在该规模下结果不正确，需要调试。


## 文件结构

```
student/
├── CMakeLists.txt          # CMake 构建配置
├── README.md               # 本文档
├── include/
│   └── router.h            # 数据结构与函数声明（无需修改）
└── src/
    ├── main.c              # 主函数与 I/O 逻辑（已实现，无需修改）
    └── router.c            # 核心实现文件（需要完成）
```

## 你的任务

打开 [src/router.c](src/router.c)，你会看到三个需要实现的函数：

### 1. `router_create(int num_experts, int top_k)`

分配并初始化 `Router` 结构体。

```c
Router* router_create(int num_experts, int top_k) {
    // TODO: 分配内存并初始化 Router 结构
    // 返回指向新分配的 Router 的指针，失败时返回 NULL
}
```

### 2. `router_route(Router* router, const int* scores, int num_tokens, RouteResult* out)`

这是核心函数，需要为所有 token 完成路由。

- **输入**：
  - `router`：路由器对象
  - `scores`：一个大小为 `num_tokens * num_experts` 的一维数组，按行存储
    - 第 `i` 个 token 对第 `j` 个 expert 的得分位于 `scores[i * num_experts + j]`
  - `num_tokens`：token 数量
  
- **输出**（填充 `out` 指向的结构）：
  - `out->topk_indices[i * top_k + r]`：第 `i` 个 token 的第 `r` 个选中 expert 的 ID
  - `out->topk_scores[i * top_k + r]`：对应的得分
  - `out->expert_load[j]`：expert j 被选中的总次数

**规则要求**：
1. 对每个 token，选出得分最高的前 k 个 expert
2. **当分数相同时，编号更小的 expert 优先**（这很重要！）
3. 结果按"分数从高到低、编号从小到大"的顺序排列

### 3. `router_destroy(Router* router)`

释放 `Router` 及其关联的所有内存。

```c
void router_destroy(Router* router) {
    // TODO: 释放 router 指向的内存
}
```
